# ShoppingCartWeb (MySQL + Tomcat 11 + Bootstrap)

This project is a Java Servlet + JSP shopping cart configured to use **MySQL**.
Root password used in this project: **1234** (update as needed).

## Contents
- `pom.xml` - Maven config (includes MySQL connector)
- `db_init.sql` - SQL to create tables and seed sample data (products reference images in `/images`)
- `src/main/java` - Java sources (servlets, DatabaseConnection)
- `src/main/webapp` - JSPs and `images/`

## MySQL installation & DB setup (Windows)
1. Run `mysql-installer-community-8.0.44.0.msi` and install MySQL Server. Create root password `1234` during setup (or change code below).
2. Open MySQL Shell or command line:
   ```bash
   mysql -u root -p
   Enter password: 1234
   ```
3. Create database and load schema:
   ```sql
   CREATE DATABASE shoppingcart CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   USE shoppingcart;
   SOURCE db_init.sql;
   ```

## IntelliJ IDEA + Tomcat 11 setup
1. Open IntelliJ → *Open* → choose this project folder.
2. Let Maven import dependencies (or run `mvn clean package`).
3. Configure Tomcat 11 in IntelliJ:
   - Run → Edit Configurations → + → Tomcat Server → Local.
   - Point to Tomcat 11 installation folder.
   - Under *Deployment*, add artifact `ShoppingCartWeb:war exploded`.
4. Ensure `DatabaseConnection.java` credentials match your MySQL root user and host. Current settings:
   ```java
   JDBC_URL = "jdbc:mysql://localhost:3306/shoppingcart?useSSL=false&serverTimezone=UTC";
   JDBC_USER = "root";
   JDBC_PASSWORD = "1234";
   ```
5. Start Tomcat run configuration. Visit `http://localhost:8080/ShoppingCartWeb/`

## Additional features you might want to add later
- Password hashing (BCrypt)
- User profiles & order history pages
- Product search and categories
- Image upload instead of storing URLs (store images in DB or cloud)
- Pagination and lazy loading for very large catalogs
- Admin dashboard to add/edit products and view orders
- Email notifications on checkout

## Notes
- Passwords are stored plain-text for demo purposes. Use hashing in production.
- If you change MySQL password, update `DatabaseConnection.java` and restart Tomcat.
