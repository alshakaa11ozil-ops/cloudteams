-- Run this on MySQL after creating database 'shoppingcart'
-- Example: mysql -u root -p  (then) CREATE DATABASE shoppingcart; USE shoppingcart; SOURCE db_init.sql;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  price DOUBLE NOT NULL,
  image_url VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  total DOUBLE,
  status VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT,
  product_id INT,
  quantity INT,
  price DOUBLE
);

-- seed sample user (password plain for demo)
INSERT IGNORE INTO users (username, password) VALUES ('demo', 'demo'), ('admin', 'admin');

-- seed products with image paths (images/ folder)
INSERT IGNORE INTO products (name, price, image_url) VALUES
('Wireless Mouse', 19.99, 'images/mouse.png'),
('USB-C Cable', 9.99, 'images/cable.png'),
('Mechanical Keyboard', 79.99, 'images/keyboard.png'),
('27in Monitor', 199.99, 'images/monitor.png'),
('Gaming Laptop', 899.99, 'images/laptop.png');
