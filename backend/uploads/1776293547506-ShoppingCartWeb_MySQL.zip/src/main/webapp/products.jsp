<%@ page import="java.util.*" %>
<%@ page contentType="text/html;charset=UTF-8" %>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Products - ShoppingCart</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .product-grid { max-height: 70vh; overflow-y: auto; }
    .product-card img { object-fit: cover; height:160px; }
  </style>
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand" href="products">ShoppingCart</a>
    <div>
      <a class="btn btn-outline-light me-2" href="cart">Cart</a>
      <c:if test="${not empty sessionScope.username}">
        <span class="text-white me-2">Hello, ${sessionScope.username}</span>
        <a class="btn btn-outline-light" href="logout">Logout</a>
      </c:if>
      <c:if test="${empty sessionScope.username}">
        <a class="btn btn-outline-light" href="login">Login</a>
      </c:if>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <c:if test="${not empty sessionScope.msg}">
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      ${sessionScope.msg}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <%
      session.removeAttribute("msg");
    %>
  </c:if>

  <div class="product-grid row row-cols-1 row-cols-md-3 g-4">
    <%
      List<Map<String,Object>> products = (List<Map<String,Object>>) request.getAttribute("products");
      for (Map<String,Object> p : products) {
    %>
    <div class="col">
      <div class="card h-100 product-card">
        <img src="<%= p.get("image") %>" class="card-img-top" alt="<%= p.get("name") %>">
        <div class="card-body d-flex flex-column">
          <h5 class="card-title"><%= p.get("name") %></h5>
          <p class="card-text">$<%= p.get("price") %></p>
          <form method="post" action="cart" class="mt-auto">
            <input type="hidden" name="productId" value="<%= p.get("id") %>">
            <div class="input-group">
              <input type="number" name="quantity" value="1" min="1" class="form-control" style="max-width:90px">
              <button class="btn btn-primary">Add to cart</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <% } %>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
