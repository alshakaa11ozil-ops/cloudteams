<%@ page import="java.util.*,model.CartItem" %>
<%@ page contentType="text/html;charset=UTF-8" %>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Cart - ShoppingCart</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand" href="products">ShoppingCart</a>
    <div>
      <a class="btn btn-outline-light" href="products">Continue shopping</a>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <c:if test="${not empty requestScope.msg}">
    <div class="alert alert-info">${requestScope.msg}</div>
  </c:if>

  <h3>Your Cart</h3>
  <%
    List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
    if (cart == null || cart.isEmpty()) {
  %>
    <p>Your cart is empty.</p>
    <a class="btn btn-primary" href="products">Shop now</a>
  <%
    } else {
      double total = 0;
  %>
    <table class="table">
      <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Total</th><th></th></tr></thead>
      <tbody>
      <%
        for (CartItem it : cart) {
          total += it.getTotal();
      %>
        <tr>
          <td><%= it.getName() %></td>
          <td>$<%= it.getPrice() %></td>
          <td><%= it.getQuantity() %></td>
          <td>$<%= it.getTotal() %></td>
          <td><a class="btn btn-sm btn-danger" href="cart?remove=<%= it.getProductId() %>">Remove</a></td>
        </tr>
      <% } %>
      </tbody>
    </table>
    <div class="d-flex justify-content-between align-items-center">
      <h4>Total: $<%= total %></h4>
      <form method="post" action="checkout">
        <button class="btn btn-success">Checkout</button>
      </form>
    </div>
  <% } %>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
