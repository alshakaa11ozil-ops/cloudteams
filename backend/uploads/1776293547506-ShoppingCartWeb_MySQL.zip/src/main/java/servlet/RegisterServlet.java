package servlet;

import database.DatabaseConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet(name="RegisterServlet", urlPatterns = {"/register"})
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password"); // demo plain-text
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO users (username,password) VALUES (?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ps.executeUpdate();
            req.getSession().setAttribute("msg", "Registration successful. You can log in now.");
            resp.sendRedirect(req.getContextPath() + "/login");
        } catch (SQLException e) {
            req.setAttribute("error", "Username may already exist.");
            req.getRequestDispatcher("/register.jsp").forward(req, resp);
        }
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/register.jsp").forward(req, resp);
    }
}
