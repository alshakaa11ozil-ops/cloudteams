package servlet;

import database.DatabaseConnection;
import model.CartItem;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.List;

@WebServlet(name="CheckoutServlet", urlPatterns = {"/checkout"})
public class CheckoutServlet extends HttpServlet {

    @SuppressWarnings("unchecked")
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        if (userId == null) {
            session.setAttribute("msg", "Please login to checkout.");
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }
        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
        if (cart == null || cart.isEmpty()) {
            req.setAttribute("msg", "Cart is empty.");
            req.getRequestDispatcher("/cart.jsp").forward(req, resp);
            return;
        }
        double total = cart.stream().mapToDouble(CartItem::getTotal).sum();

        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO orders (user_id,total,status) VALUES (?,?,?)", Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, userId);
            ps.setDouble(2, total);
            ps.setString(3, "Processing");
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            keys.next();
            int orderId = keys.getInt(1);

            PreparedStatement itemStmt = conn.prepareStatement(
                    "INSERT INTO order_items (order_id,product_id,quantity,price) VALUES (?,?,?,?)");
            for (CartItem item : cart) {
                itemStmt.setInt(1, orderId);
                itemStmt.setInt(2, item.getProductId());
                itemStmt.setInt(3, item.getQuantity());
                itemStmt.setDouble(4, item.getPrice());
                itemStmt.addBatch();
            }
            itemStmt.executeBatch();
            conn.commit();
            session.removeAttribute("cart");
            req.setAttribute("msg", "Order placed successfully! Total: $" + total);
            req.getRequestDispatcher("/checkout.jsp").forward(req, resp);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
