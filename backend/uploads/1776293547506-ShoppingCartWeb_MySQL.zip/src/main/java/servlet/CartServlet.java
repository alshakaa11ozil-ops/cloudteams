package servlet;

import database.DatabaseConnection;
import model.CartItem;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet(name="CartServlet", urlPatterns = {"/cart"})
public class CartServlet extends HttpServlet {

    @SuppressWarnings("unchecked")
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession();
        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
        if (cart == null) cart = new ArrayList<>();

        String remove = req.getParameter("remove");
        if (remove != null) {
            int pid = Integer.parseInt(remove);
            cart.removeIf(i -> i.getProductId() == pid);
            session.setAttribute("cart", cart);
            req.setAttribute("msg", "Item removed from cart.");
        }

        req.getRequestDispatcher("/cart.jsp").forward(req, resp);
    }

    @SuppressWarnings("unchecked")
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        int productId = Integer.parseInt(req.getParameter("productId"));
        int qty = Integer.parseInt(req.getParameter("quantity"));

        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("SELECT id,name,price FROM products WHERE id=?");
            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                CartItem item = new CartItem(rs.getInt("id"), rs.getString("name"), rs.getDouble("price"), qty);
                HttpSession session = req.getSession();
                List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
                if (cart == null) cart = new ArrayList<>();
                boolean found = false;
                for (CartItem c : cart) {
                    if (c.getProductId() == item.getProductId()) {
                        c.setQuantity(c.getQuantity() + qty);
                        found = true;
                        break;
                    }
                }
                if (!found) cart.add(item);
                session.setAttribute("cart", cart);
                session.setAttribute("msg", item.getName() + " added to cart.");
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
        resp.sendRedirect(req.getContextPath() + "/products");
    }
}
